package com.sample.example.service;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

public interface IFileDataService {
	ResponseEntity<List<List<String>>> processExcelFile(MultipartFile file, int startRow);
    ResponseEntity<String> convertXmlToJson(MultipartFile file);

}
