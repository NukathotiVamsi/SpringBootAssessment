package com.sample.example.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.sample.example.service.IFileDataService;

public class FileDataController {
	private final IFileDataService fileDataService;

	public FileDataController(IFileDataService fileDataService) {
		super();
		this.fileDataService = fileDataService;
	}

	@PostMapping("/upload/excel")
	public ResponseEntity<List<List<String>>> uploadExcel(@RequestParam("file") MultipartFile file,
			@RequestParam(value = "startRow", defaultValue = "0") int startRow) {
		return fileDataService.processExcelFile(file, startRow);
	}

	@PostMapping("/upload/xml")
	public ResponseEntity<String> uploadXml(@RequestParam("file") MultipartFile file) {
		return fileDataService.convertXmlToJson(file);
	}
}