package com.sample.example.service.impl;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.*;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.sample.example.service.IFileDataService;

@Service
public class FileDataService implements IFileDataService {

	private static final String UPLOAD_DIR = "uploads";
	private final ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public ResponseEntity<List<List<String>>> processExcelFile(MultipartFile file, int startRow) {
		List<List<String>> data = new ArrayList<>();
		try (InputStream inputStream = file.getInputStream()) {
			Workbook workbook = WorkbookFactory.create(inputStream);
			Sheet sheet = workbook.getSheetAt(0);

			for (int i = startRow; i <= sheet.getLastRowNum(); i++) {
				Row row = sheet.getRow(i);
				if (row != null) {
					List<String> rowData = new ArrayList<>();
					for (Cell cell : row) {
						rowData.add(cell.toString());
					}
					data.add(rowData);
				}
			}
			return ResponseEntity.ok(data);
		} catch (IOException e) {
			return ResponseEntity.badRequest().body(null);
		}
	}

	@Override
	public ResponseEntity<String> convertXmlToJson(MultipartFile file) {
		try {
			File uploadDir = new File(UPLOAD_DIR);
			if (!uploadDir.exists()) {
				uploadDir.mkdirs();
			}

			Path filePath = Paths.get(UPLOAD_DIR, file.getOriginalFilename());
			Files.write(filePath, file.getBytes());

			XmlMapper xmlMapper = new XmlMapper();
			JsonNode jsonNode = xmlMapper.readTree(file.getBytes());

			String jsonOutput = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(jsonNode);

			Path jsonPath = Paths.get(UPLOAD_DIR, "converted.json");
			Files.write(jsonPath, jsonOutput.getBytes());

			return ResponseEntity.ok("File converted and saved at: " + jsonPath.toAbsolutePath());
		} catch (IOException e) {
			return ResponseEntity.badRequest().body("Error processing file: " + e.getMessage());
		}

	}

}
