package com.sample.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sample.example.entity.FileData;

public interface FileDataRepository extends JpaRepository<FileData, Long> {

}
